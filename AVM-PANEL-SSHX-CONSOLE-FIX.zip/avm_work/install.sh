#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/avm-panel"
DATA_DIR="/var/lib/avm-panel"
SERVICE="avm-panel"
PORT_DEFAULT="3000"

banner() {
  clear 2>/dev/null || true
  echo '================================================'
  echo '   █████╗ ██╗   ██╗███╗   ███╗'
  echo '  ██╔══██╗██║   ██║████╗ ████║'
  echo '  ███████║██║   ██║██╔████╔██║'
  echo '  ██╔══██║╚██╗ ██╔╝██║╚██╔╝██║'
  echo '  ██║  ██║ ╚████╔╝ ██║ ╚═╝ ██║'
  echo '  ╚═╝  ╚═╝  ╚═══╝  ╚═╝     ╚═╝'
  echo '             AVM PANEL'
  echo '================================================'
  echo '             Server VPS Panel Manager'
  echo '================================================'
}

need_root() { [[ "${EUID}" -eq 0 ]] || { echo 'Please run as root: bash install.sh'; exit 1; }; }
service_action() {
  systemctl "$1" "$SERVICE"
  systemctl --no-pager --full status "$SERVICE" || true
}
install_panel() {
  need_root
  local src; src="$(cd "$(dirname "$0")" && pwd)"
  [[ -f "$src/hvm.py" && -f "$src/requirements.txt" ]] || { echo 'Run this installer from the extracted AVM PANEL package directory.'; return 1; }
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip curl ca-certificates build-essential
  mkdir -p "$APP_DIR" "$DATA_DIR"
  cp -a "$src/." "$APP_DIR/"
  chmod +x "$APP_DIR/install.sh"
  python3 -m venv "$APP_DIR/.venv"
  "$APP_DIR/.venv/bin/pip" install --upgrade pip wheel
  "$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
  if [[ ! -f "$APP_DIR/.env" ]]; then
    local secret; secret="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
    cat > "$APP_DIR/.env" <<EOF
PANEL_NAME=AVM PANEL
PANEL_DEVELOPER=AVM PANEL
HOST=0.0.0.0
PORT=${PORT_DEFAULT}
SECRET_KEY=${secret}
DATABASE_PATH=${DATA_DIR}/avm.db
EOF
    chmod 600 "$APP_DIR/.env"
  fi
  cat > "/etc/systemd/system/${SERVICE}.service" <<EOF
[Unit]
Description=AVM PANEL VPS Manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
ExecStart=${APP_DIR}/.venv/bin/python ${APP_DIR}/hvm.py
Restart=on-failure
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$SERVICE"
  systemctl restart "$SERVICE"
  echo
  echo 'AVM PANEL installed successfully.'
  echo "Panel URL: http://YOUR_SERVER_IP:${PORT_DEFAULT}"
  echo "Service: systemctl status ${SERVICE}"
  echo "Database and persistent data: ${DATA_DIR}"
}
uninstall_panel() {
  need_root
  echo 'This removes AVM PANEL application files and its systemd service.'
  echo "Database is kept in ${DATA_DIR} as a safety backup."
  read -r -p 'Type REMOVE to continue: ' answer
  [[ "$answer" == 'REMOVE' ]] || { echo 'Cancelled.'; return; }
  systemctl disable --now "$SERVICE" 2>/dev/null || true
  rm -f "/etc/systemd/system/${SERVICE}.service"
  systemctl daemon-reload
  rm -rf "$APP_DIR"
  echo 'AVM PANEL removed. Persistent database retained in /var/lib/avm-panel.'
}
menu() {
  while true; do
    banner
    echo ' [1] Install / Update AVM PANEL'
    echo ' [2] Uninstall AVM PANEL'
    echo ' [3] Start panel'
    echo ' [4] Stop panel'
    echo ' [5] Restart panel'
    echo ' [6] Panel status'
    echo ' [0] Exit'
    echo '------------------------------------------------'
    read -r -p 'Select option: ' choice
    case "$choice" in
      1) install_panel ;;
      2) uninstall_panel ;;
      3) need_root; service_action start ;;
      4) need_root; service_action stop ;;
      5) need_root; service_action restart ;;
      6) need_root; service_action status ;;
      0) exit 0 ;;
      *) echo 'Invalid option.' ;;
    esac
    echo
    read -r -p 'Press Enter to return to menu...' _
  done
}
menu

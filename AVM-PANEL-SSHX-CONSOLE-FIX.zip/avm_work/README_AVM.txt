AVM PANEL v5 package
====================

Install:
  unzip AVM-PANEL-v5.zip
  cd avm_work   (or the extracted package folder)
  sudo bash install.sh

Installer menu:
  1 Install / Update
  2 Uninstall (keeps /var/lib/avm-panel database)
  3 Start
  4 Stop
  5 Restart
  6 Status

Panel service: avm-panel
Application: /opt/avm-panel
Persistent database: /var/lib/avm-panel/avm.db
Default web port: 3000

Important:
- Change the initial administrator credentials after first login.
- Keep /opt/avm-panel/.env private; it contains the encryption key used for VPS passwords.
- VPS passwords are encrypted in the database. Password reveal is available only to the VPS owner or an admin after login.
- Console auto-connect uses the container IP visible to the panel node. For remote nodes, the panel node must be able to route to the container's private IP.
- SSHX creates a shareable terminal link. Treat that link as a credential and do not publish it.


AVM PANEL LITE PERFORMANCE NOTES
- VPS provisioning is serialized per node to avoid concurrent image unpacking exhausting host RAM.
- Memory and CPU limits are applied during LXD init, before first boot.
- Existing container-name collisions are reported; they are never auto-deleted.
- Partial containers created by the current failed request are cleaned up.
- Remote node URL accepts an HTTPS Cloudflare Tunnel hostname. Configure the tunnel to forward to the node-agent listener and use the same API key on both sides.
- For a 16 GB host, start with a maximum of one concurrent VPS creation per node.
